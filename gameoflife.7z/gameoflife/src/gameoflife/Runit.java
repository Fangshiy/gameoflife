package gameoflife;

public class Runit {
	public static void main(String[] args) {
		new User();
	}
}
