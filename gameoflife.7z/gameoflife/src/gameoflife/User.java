package gameoflife;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class User extends JPanel implements MouseListener,Runnable,ActionListener,MouseMotionListener{
	private static final long serialVersionUID = 1L;
	
	int length=510;   //���泤��
	int width=650;    //�������
	
	int x=100;       //����λ��
	int y=100;
	
	static int gridNum=50;    //������
	static int gridSize=10;   //���Ӵ�С
	static int maxGridSize=gridNum*gridSize;    //���ı߽�ֵ
	static Cell cell=new Cell();  //ϸ�����״̬
	Random random=new Random(); //�������
	
	JPanel p=new JPanel();
	JButton bt1=new JButton("START");
	JButton bt2=new JButton("PAUSE");
	JButton bt3=new JButton("REFRESH");
	JButton bt4=new JButton("RANDOM");
	boolean running=false;
	Thread myThread;
	JFrame fe;
	
	public User() 
	{
		fe=new JFrame("�� �� �� Ϸ   Demo");
		fe.setBounds(x,y,length,width);
		bt1.setBounds(50,maxGridSize+50,100,60);
		bt1.setBorder(BorderFactory.createRaisedBevelBorder());
		bt2.setBounds(150,maxGridSize+50,100,60);
		bt2.setBorder(BorderFactory.createRaisedBevelBorder());
		bt3.setBounds(250,maxGridSize+50,100,60);
		bt3.setBorder(BorderFactory.createRaisedBevelBorder());
		bt4.setBounds(350,maxGridSize+50,100,60);
		bt4.setBorder(BorderFactory.createRaisedBevelBorder());
		bt2.setEnabled(false);
		bt3.setEnabled(false);
		fe.add(bt1);
		fe.add(bt2);
		fe.add(bt3);
		fe.add(bt4);
		bt1.addActionListener(this);
		bt2.addActionListener(this);
		bt3.addActionListener(this);
		bt4.addActionListener(this);
		fe.getContentPane().setBackground(Color.LIGHT_GRAY);
		fe.setLayout(null);
		this.setBounds(0,0,maxGridSize+1, maxGridSize+1);    //�������
		fe.add(this);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		fe.setVisible(true);
		fe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fe.setResizable(false);
	}

	//��ʼ��  ������
	public void paint(Graphics g)
	{
		g.setColor(Color.BLACK);
		for(int i=0;i<=gridNum;i++) {
			g.drawLine(0, i*gridSize, maxGridSize, i*gridSize);
		}
		for(int i=0;i<=gridNum;i++) {
			g.drawLine(i*gridSize, 0, i*gridSize, maxGridSize);
		}
	}
	
	public void run()
	{
		while(running) {
			update();
			try {
				Thread.sleep(200L);
			} catch (InterruptedException e) {
				break;
			}
		}
	}
	
	//ϸ����� �������ú�
	public void fill(int px,int py) 
	{
		int n=py/gridSize;
		int m=px/gridSize;
		Graphics g=this.getGraphics();
		if(cell.now[n][m]==true) {
			g.setColor(Color.BLUE);
			g.fillRect(m*gridSize+1, n*gridSize+1, gridSize-1,gridSize-1);
		}
		else if(cell.now[n][m]==false) {
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect(m*gridSize+1, n*gridSize+1, gridSize-1,gridSize-1);
		}
	
	}
	
	public void update()
	{
		cell=Rules.getIsAlive();   //��ȡ��һ��ϸ��״̬
		Graphics g=this.getGraphics();
		for(int i=0;i<gridNum;i++) {
			for(int j=0;j<gridNum;j++) {
				if(cell.now[i][j]==true) {   //ϸ������
					g.setColor(Color.RED);
					g.fillRect(j*gridSize+1, i*gridSize+1, gridSize-1,gridSize-1);
				}
				else {
					g.setColor(Color.LIGHT_GRAY);
					g.fillRect(j*gridSize+1, i*gridSize+1, gridSize-1,gridSize-1);
				}
			}
		}
	}
	
	public void mousePressed(MouseEvent e) {
		int px=e.getX();
		int py=e.getY();
		if(px>=0&&px<=maxGridSize&&py>=0&&py<=maxGridSize)  
		{
			cell.now[py/gridSize][px/gridSize]=true;   //�ı��߼�ֵ
			fill(px,py);
		}
	}
	public void mouseDragged(MouseEvent e) {
		 mousePressed(e); 	
	}
	public void mouseMoved(MouseEvent e) {}
	public void mouseClicked(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt1) {
			myThread=new Thread(this);
			running=true;
			myThread.start();
			bt1.setEnabled(false);
			bt2.setEnabled(true);
			bt3.setEnabled(true);
			bt1.setText("COUNTINUE");
		}
		else if(e.getSource()==bt2) {
			running=false;
			myThread.interrupt();
			bt1.setEnabled(true);
			bt2.setEnabled(false);
		}
		else if(e.getSource()==bt3) {
			for(int i=0;i<gridNum;i++) {
				for(int j=0;j<gridNum;j++) {
					cell.now[i][j]=false;
				}
			}
			bt1.setEnabled(true);
			bt2.setEnabled(false);
			bt3.setEnabled(false);
			bt1.setText("START");
			myThread.interrupt();
			update();
		}
		else if(e.getSource()==bt4) {
			for(int i=0;i<gridNum;i++) 
				for(int j=0;j<gridNum;j++) {
					cell.now[i][j]=random.nextBoolean();
					}for(int i=0;i<gridNum;i++) 
						for(int j=0;j<gridNum;j++) {
							fill(i*gridSize,j*gridSize);
							}}
	}
	
	public static boolean[][] getIsAlive()
	{
		return cell.now;
	}
	
	public static int getGridNum()
	{
		return gridNum;
	}
	
	public static int getmaxGridSize()
	{
		return maxGridSize;
	}

}
