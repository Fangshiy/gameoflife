package gameoflife;

public class Cell {
	static int gridNum=User.gridNum;
	boolean[][] now=new boolean[gridNum+1][gridNum+1];
	static boolean[][] next=new boolean[gridNum+1][gridNum+1];
	
}
